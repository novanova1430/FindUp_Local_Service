import React, { useState } from 'react';
import { Download, Code2, Check, ExternalLink, X } from 'lucide-react';

export const FloatingDownloadButton: React.FC = () => {
  const [downloaded, setDownloaded] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);

  const handleDownload = () => {
    // Direct anchor download
    const link = document.createElement('a');
    link.href = '/findup-code.zip';
    link.download = 'findup-project.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloaded(true);
    setShowInstructions(true);
    setTimeout(() => setDownloaded(false), 4000);
  };

  return (
    <>
      {/* Floating Action Button (Always Visible in Bottom-Right Corner) */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-2">
        <button
          type="button"
          onClick={handleDownload}
          className="flex items-center gap-2 px-4 py-3 rounded-2xl text-xs sm:text-sm font-extrabold text-[#473C33] bg-[#FEC868] hover:bg-[#FDA769] border-2 border-[#473C33]/20 shadow-2xl hover:shadow-xl transition-all duration-300 cursor-pointer active:scale-95 group animate-bounce hover:animate-none"
          title="Download Complete Codebase for VS Code"
          aria-label="Download Code for VS Code"
        >
          {downloaded ? (
            <>
              <Check className="w-5 h-5 text-emerald-700" />
              <span>Downloading ZIP...</span>
            </>
          ) : (
            <>
              <div className="w-6 h-6 rounded-lg bg-[#473C33] text-white flex items-center justify-center shrink-0 group-hover:rotate-12 transition-transform">
                <Download className="w-3.5 h-3.5 text-[#FEC868]" />
              </div>
              <div className="text-left leading-tight">
                <div className="text-xs font-black uppercase tracking-wider text-[#473C33]">
                  Download for VS Code
                </div>
                <div className="text-[10px] text-[#473C33]/80 font-medium">
                  Complete Project .ZIP (14 MB)
                </div>
              </div>
            </>
          )}
        </button>

        {/* Quick Instructions helper modal */}
        {showInstructions && (
          <div className="bg-white rounded-2xl border-2 border-slate-200 shadow-2xl p-4 max-w-xs text-xs text-[#473C33] space-y-2.5 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <div className="flex items-center justify-between pb-1 border-b border-slate-100">
              <span className="font-extrabold flex items-center gap-1.5 text-xs text-[#473C33]">
                <Code2 className="w-4 h-4 text-emerald-600" />
                How to run in VS Code:
              </span>
              <button
                type="button"
                onClick={() => setShowInstructions(false)}
                className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <ol className="list-decimal pl-4 space-y-1 text-[11px] text-slate-600 font-medium">
              <li>Extract <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-slate-800">findup-project.zip</code></li>
              <li>Open the folder in <b>VS Code</b></li>
              <li>Open terminal and run: <code className="block mt-0.5 font-mono bg-slate-800 text-amber-300 p-1 rounded text-[10px]">npm install</code></li>
              <li>Start dev server: <code className="block mt-0.5 font-mono bg-slate-800 text-emerald-300 p-1 rounded text-[10px]">npm run dev</code></li>
              <li>Open <code className="font-mono text-blue-600">http://localhost:3000</code> in your browser!</li>
            </ol>
          </div>
        )}
      </div>
    </>
  );
};
