import React, { useState } from 'react';
import { Palette, Check, Sparkles, Download } from 'lucide-react';
import { PALETTE_18 } from '../../context/ThemeContext';

export const ThemeSwitcher: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const swatches = [
    { name: 'Sage Olive', hex: PALETTE_18.green, code: '#ABC270', desc: 'Headers, badges & accents' },
    { name: 'Honey Gold', hex: PALETTE_18.yellow, code: '#FEC868', desc: 'Primary buttons & highlights' },
    { name: 'Apricot Peach', hex: PALETTE_18.peach, code: '#FDA769', desc: 'Action tags & active chips' },
    { name: 'Deep Espresso', hex: PALETTE_18.espresso, code: '#473C33', desc: 'Headings, typography & contrast' },
  ];

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
        title="Palette 18: #ABC270, #FEC868, #FDA769, #473C33"
        aria-label="Palette 18 Active"
      >
        <div className="flex items-center -space-x-1">
          <span className="w-3 h-3 rounded-full border border-white shadow-2xs" style={{ backgroundColor: '#ABC270' }} />
          <span className="w-3 h-3 rounded-full border border-white shadow-2xs" style={{ backgroundColor: '#FEC868' }} />
          <span className="w-3 h-3 rounded-full border border-white shadow-2xs" style={{ backgroundColor: '#FDA769' }} />
          <span className="w-3 h-3 rounded-full border border-white shadow-2xs" style={{ backgroundColor: '#473C33' }} />
        </div>
        <span className="hidden sm:inline text-[11px] text-slate-700 font-bold ml-1">
          Palette 18
        </span>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white shadow-xl border border-slate-200 p-3 z-50 text-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-2 py-1.5 border-b border-slate-100 mb-2 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Exclusive 4-Colour Palette</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  Matched exactly to uploaded design
                </div>
              </div>
              <span className="text-[10px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">
                Active
              </span>
            </div>

            <div className="space-y-2 py-1">
              {swatches.map((s) => (
                <div
                  key={s.code}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-50/80 border border-slate-100 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-6 h-6 rounded-lg border border-black/10 shadow-xs shrink-0 flex items-center justify-center text-white font-mono text-[9px] font-bold"
                      style={{ backgroundColor: s.hex }}
                    />
                    <div>
                      <div className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                        <span>{s.name}</span>
                        <code className="text-[10px] font-mono px-1 py-0.2 rounded bg-white text-slate-600 border border-slate-200">
                          {s.code}
                        </code>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{s.desc}</div>
                    </div>
                  </div>
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                </div>
              ))}
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-100 flex flex-col gap-2">
              <a
                href="/findup-code.zip"
                download="findup-project.zip"
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold text-[#473C33] bg-[#FEC868] hover:bg-[#FDA769] transition-colors shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Source Code (.ZIP)</span>
              </a>
              <div className="text-[10px] text-slate-500 leading-relaxed text-center font-medium">
                Palette 18: Only these 4 colors & warm linen canvas (#FAF8F2) are used.
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
